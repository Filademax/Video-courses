import Link from "next/link";
import { T } from "@/lib/theme";

const TOOLS = [
  { id: "ai-video", title: "AI Video", desc: "Generate a complete short video from a text prompt.", live: false },
  { id: "long-video", title: "Long Video", desc: "Turn a topic into a full long-form video production.", live: false },
  { id: "ai-image", title: "AI Image", desc: "Generate on-brand images in any style.", live: false },
  { id: "ai-voiceover", title: "AI Voiceover", desc: "Turn a script into natural narration.", live: false },
  { id: "ai-music", title: "AI Music", desc: "Generate original background music.", live: false },
  { id: "ai-script", title: "AI Script", desc: "Write a full script with hook, body, and CTA.", live: true },
  { id: "ai-story", title: "AI Story", desc: "Develop a full story with characters and chapters.", live: true },
  { id: "ai-social", title: "AI Social Posts", desc: "Generate platform-specific captions and posts.", live: true },
  { id: "ai-ad", title: "AI Advertisement", desc: "Generate a full ad concept and script.", live: true },
  { id: "ai-thumbnail", title: "AI Thumbnail", desc: "Generate scroll-stopping thumbnail variations.", live: false },
];

export default function CreatePage() {
  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>Create</h1>
      <p style={{ fontSize: 13.5, color: T.textMuted, margin: "0 0 22px" }}>
        Tools marked <b>live</b> call a real AI model right now. The rest run in development mode until a provider key is added — see README.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))", gap: 14 }}>
        {TOOLS.map((tool) => (
          <Link key={tool.id} href={`/create/${tool.id}`} style={{ textDecoration: "none", color: "inherit" }}>
            <div style={{ border: `1px solid ${T.border}`, borderRadius: 14, padding: 18, background: T.surface, height: "100%", boxSizing: "border-box" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div style={{ fontSize: 14.5, fontWeight: 600, marginBottom: 6 }}>{tool.title}</div>
                {tool.live && <span style={{ fontSize: 10.5, fontWeight: 700, color: T.green, background: "rgba(52,211,153,0.14)", padding: "2px 7px", borderRadius: 999 }}>LIVE</span>}
              </div>
              <div style={{ fontSize: 12.5, color: T.textMuted, lineHeight: 1.5 }}>{tool.desc}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
