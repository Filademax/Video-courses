"use client";
import { useState, useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { T, gradBg } from "@/lib/theme";

type Job = {
  id: string; status: string; progress: number; output: any; error: string | null; tool_type: string;
};

export default function ToolPage() {
  const params = useParams();
  const router = useRouter();
  const toolType = params.tool as string;

  const [prompt, setPrompt] = useState("");
  const [projectName, setProjectName] = useState("");
  const [job, setJob] = useState<Job | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const channelRef = useRef<ReturnType<ReturnType<typeof createClient>["channel"]> | null>(null);

  useEffect(() => {
    return () => {
      if (channelRef.current) createClient().removeChannel(channelRef.current);
    };
  }, []);

  async function handleGenerate() {
    if (!prompt.trim()) {
      setFormError("Enter a prompt first.");
      return;
    }
    setFormError("");
    setSubmitting(true);
    const supabase = createClient();

    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ toolType, prompt }),
    });
    const json = await res.json();
    setSubmitting(false);

    if (!res.ok) {
      setFormError(json.error || "Generation failed.");
      return;
    }

    // fetch the job row and subscribe to further updates (covers long-running jobs)
    const { data: jobRow } = await supabase.from("generation_jobs").select("*").eq("id", json.jobId).single();
    setJob(jobRow as Job);

    const channel = supabase
      .channel(`job-${json.jobId}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "generation_jobs", filter: `id=eq.${json.jobId}` },
        (payload) => setJob(payload.new as Job))
      .subscribe();
    channelRef.current = channel;
  }

  async function handleSaveProject() {
    if (!job) return;
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    await supabase.from("projects").insert({
      user_id: user!.id,
      name: projectName || prompt.slice(0, 40),
      tool_type: toolType,
    });
    router.push("/projects");
  }

  return (
    <div>
      <button onClick={() => router.push("/create")} style={{ background: "none", border: "none", color: T.textMuted, fontSize: 13, cursor: "pointer", padding: 0, marginBottom: 18 }}>
        ← All tools
      </button>
      <h1 style={{ fontSize: 21, fontWeight: 600, margin: "0 0 4px", textTransform: "capitalize" }}>{toolType.replace(/-/g, " ")}</h1>
      <p style={{ fontSize: 13, color: T.textMuted, margin: "0 0 22px" }}>Enter a prompt and generate.</p>

      <div style={{ display: "grid", gridTemplateColumns: job ? "1fr 1fr" : "1fr", gap: 24, maxWidth: 900 }}>
        <div style={{ border: `1px solid ${T.border}`, borderRadius: 14, padding: 20, background: T.surface }}>
          <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, color: T.textMuted, marginBottom: 6 }}>Project name</label>
          <input value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Untitled" style={inputStyle} />
          <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, color: T.textMuted, margin: "14px 0 6px" }}>Prompt</label>
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Describe what you want to create..." style={{ ...inputStyle, minHeight: 100, resize: "vertical" }} />
          {formError && <p style={{ color: T.red, fontSize: 12.5, marginTop: 8 }}>{formError}</p>}
          <button onClick={handleGenerate} disabled={submitting} style={{ marginTop: 16, background: gradBg, color: "#fff", border: "none", borderRadius: 10, padding: "10px 18px", fontWeight: 600, fontSize: 14, cursor: submitting ? "not-allowed" : "pointer", opacity: submitting ? 0.6 : 1 }}>
            {submitting ? "Generating…" : "Generate"}
          </button>
        </div>

        {job && (
          <div style={{ border: `1px solid ${T.border}`, borderRadius: 14, padding: 20, background: T.surface }}>
            {job.status !== "completed" && job.status !== "failed" && (
              <p style={{ fontSize: 13.5 }}>Status: {job.status} ({job.progress}%)</p>
            )}
            {job.status === "failed" && <p style={{ color: T.red, fontSize: 13.5 }}>Generation failed: {job.error}</p>}
            {job.status === "completed" && job.output && (
              <>
                {job.output.kind === "text" ? (
                  <pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit", fontSize: 13.5, lineHeight: 1.7, background: T.surface2, borderRadius: 10, padding: 16, border: `1px solid ${T.border}`, maxHeight: 320, overflowY: "auto" }}>
                    {job.output.data.text}
                  </pre>
                ) : (
                  <div style={{ fontSize: 13, color: T.textMuted, background: T.surface2, borderRadius: 10, padding: 16, border: `1px solid ${T.border}` }}>
                    {job.output.mock
                      ? "Development mode output — connect a real provider for this tool type to see actual media here."
                      : "Generated."}
                  </div>
                )}
                <button onClick={handleSaveProject} style={{ marginTop: 14, border: `1px solid ${T.border}`, background: "none", color: T.text, borderRadius: 9, padding: "9px 14px", fontSize: 13, cursor: "pointer" }}>
                  Save to project
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%", background: T.surface2, border: `1px solid ${T.border}`, borderRadius: 9,
  color: T.text, fontSize: 14, padding: "10px 12px", outline: "none", boxSizing: "border-box", fontFamily: "inherit",
};
