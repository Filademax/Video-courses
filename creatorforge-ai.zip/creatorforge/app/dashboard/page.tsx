import { createClient } from "@/lib/supabase/server";
import { T } from "@/lib/theme";
import Link from "next/link";

export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: projects } = await supabase
    .from("projects").select("*").eq("user_id", user!.id)
    .order("created_at", { ascending: false }).limit(5);

  const { data: jobs } = await supabase
    .from("generation_jobs").select("*").eq("user_id", user!.id)
    .order("created_at", { ascending: false }).limit(5);

  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>Welcome back</h1>
      <p style={{ fontSize: 13.5, color: T.textMuted, margin: "0 0 24px" }}>Create anything from an idea.</p>

      <Link href="/create" style={{ display: "inline-block", background: "linear-gradient(90deg,#7C5CFF,#4C8DFF)", color: "#fff", padding: "10px 18px", borderRadius: 10, fontWeight: 600, fontSize: 13.5, textDecoration: "none", marginBottom: 28 }}>
        + Create something
      </Link>

      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 24 }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: T.textMuted, marginBottom: 10 }}>Recent projects</div>
          {!projects?.length ? (
            <Empty text="No projects yet. Generate something and save it." />
          ) : projects.map((p) => (
            <div key={p.id} style={{ padding: "12px 4px", borderBottom: `1px solid ${T.border}` }}>
              <div style={{ fontSize: 13.5, fontWeight: 500 }}>{p.name}</div>
              <div style={{ fontSize: 11.5, color: T.textMuted }}>{p.tool_type}</div>
            </div>
          ))}
        </div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: T.textMuted, marginBottom: 10 }}>Recent generations</div>
          {!jobs?.length ? (
            <Empty text="Nothing generated yet." />
          ) : jobs.map((j) => (
            <div key={j.id} style={{ display: "flex", justifyContent: "space-between", padding: "10px 4px", borderBottom: `1px solid ${T.border}` }}>
              <span style={{ fontSize: 13 }}>{j.tool_type}</span>
              <span style={{ fontSize: 11.5, color: j.status === "completed" ? T.green : T.textMuted }}>{j.status}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <div style={{ border: `1px dashed ${T.border}`, borderRadius: 12, padding: 20, fontSize: 12.5, color: T.textMuted, textAlign: "center" }}>{text}</div>;
}
