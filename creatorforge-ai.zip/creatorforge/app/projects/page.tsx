import { createClient } from "@/lib/supabase/server";
import { T } from "@/lib/theme";

export default async function ProjectsPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: projects } = await supabase
    .from("projects").select("*").eq("user_id", user!.id)
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>Projects</h1>
      <p style={{ fontSize: 13.5, color: T.textMuted, margin: "0 0 22px" }}>Everything you save from a generation lands here.</p>
      {!projects?.length ? (
        <div style={{ border: `1px dashed ${T.border}`, borderRadius: 12, padding: 24, textAlign: "center", fontSize: 13, color: T.textMuted }}>
          No projects yet. Generate something in Create, then save it.
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 14 }}>
          {projects.map((p) => (
            <div key={p.id} style={{ border: `1px solid ${T.border}`, borderRadius: 14, padding: 16, background: T.surface }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 4 }}>{p.name}</div>
              <div style={{ fontSize: 11.5, color: T.textMuted }}>{p.tool_type} · {new Date(p.created_at).toLocaleDateString()}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
