import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { runGeneration } from "@/lib/providers";

export async function POST(request: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const body = await request.json();
  const { toolType, prompt, projectId, options } = body as {
    toolType: string; prompt: string; projectId?: string; options?: Record<string, unknown>;
  };

  if (!toolType || !prompt?.trim()) {
    return NextResponse.json({ error: "toolType and prompt are required" }, { status: 400 });
  }

  // 1. Create the job row — the UI subscribes to this row via Supabase realtime.
  const { data: job, error: insertError } = await supabase
    .from("generation_jobs")
    .insert({
      user_id: user.id,
      project_id: projectId ?? null,
      tool_type: toolType,
      prompt,
      input: options ?? {},
      status: "processing",
      progress: 10,
    })
    .select()
    .single();

  if (insertError || !job) {
    return NextResponse.json({ error: insertError?.message ?? "Could not create job" }, { status: 500 });
  }

  // 2. Run the provider. In production this should move to a background
  //    worker/queue for long-running video jobs — this route awaits it
  //    directly for simplicity, which is fine for text/image/voice/music.
  try {
    const result = await runGeneration({ toolType, prompt, options });

    const { error: updateError } = await supabase
      .from("generation_jobs")
      .update({
        status: "completed",
        progress: 100,
        output: result,
        provider: result.provider,
        model: result.model ?? null,
        completed_at: new Date().toISOString(),
      })
      .eq("id", job.id);

    if (updateError) throw updateError;

    await supabase.from("generations").insert({
      job_id: job.id,
      user_id: user.id,
      project_id: projectId ?? null,
      tool_type: toolType,
      output: result,
    });

    return NextResponse.json({ jobId: job.id, result });
  } catch (err) {
    await supabase
      .from("generation_jobs")
      .update({ status: "failed", error: (err as Error).message })
      .eq("id", job.id);
    return NextResponse.json({ error: "Generation failed", jobId: job.id }, { status: 500 });
  }
}
