import { createClient } from "@/lib/supabase/server";
import { T } from "@/lib/theme";

export default async function HistoryPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: jobs } = await supabase
    .from("generation_jobs").select("*").eq("user_id", user!.id)
    .order("created_at", { ascending: false }).limit(50);

  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>History</h1>
      <p style={{ fontSize: 13.5, color: T.textMuted, margin: "0 0 22px" }}>Every generation job on your account.</p>
      {!jobs?.length ? (
        <div style={{ border: `1px dashed ${T.border}`, borderRadius: 12, padding: 24, textAlign: "center", fontSize: 13, color: T.textMuted }}>
          No generations yet.
        </div>
      ) : (
        <div style={{ border: `1px solid ${T.border}`, borderRadius: 14, overflow: "hidden" }}>
          {jobs.map((j, i) => (
            <div key={j.id} style={{ display: "flex", justifyContent: "space-between", padding: "13px 16px", borderBottom: i < jobs.length - 1 ? `1px solid ${T.border}` : "none", background: T.surface }}>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 500 }}>{j.tool_type}</div>
                <div style={{ fontSize: 11.5, color: T.textMuted }}>{new Date(j.created_at).toLocaleString()}</div>
              </div>
              <span style={{ fontSize: 12, color: j.status === "completed" ? T.green : j.status === "failed" ? T.red : T.blue, alignSelf: "center" }}>{j.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
