import { createClient } from "@supabase/supabase-js";
import { T } from "@/lib/theme";

// Uses the service role key server-side only, so admin stats can see
// platform-wide counts rather than being scoped by a single user's RLS.
function adminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

export default async function AdminPage() {
  const supabase = adminClient();

  const [{ count: userCount }, { count: jobCount }, { count: failedCount }, { count: completedCount }] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("generation_jobs").select("*", { count: "exact", head: true }),
    supabase.from("generation_jobs").select("*", { count: "exact", head: true }).eq("status", "failed"),
    supabase.from("generation_jobs").select("*", { count: "exact", head: true }).eq("status", "completed"),
  ]);

  const stats = [
    { label: "Total users", value: userCount ?? 0 },
    { label: "Total generations", value: jobCount ?? 0 },
    { label: "Completed", value: completedCount ?? 0 },
    { label: "Failed", value: failedCount ?? 0 },
  ];

  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>Admin</h1>
      <p style={{ fontSize: 13.5, color: T.textMuted, margin: "0 0 22px" }}>Platform-wide usage. Only visible to admin accounts.</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
        {stats.map((s) => (
          <div key={s.label} style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12, padding: 16 }}>
            <div style={{ fontSize: 12.5, color: T.textMuted, marginBottom: 6 }}>{s.label}</div>
            <div style={{ fontSize: 24, fontWeight: 600 }}>{s.value}</div>
          </div>
        ))}
      </div>
      <p style={{ fontSize: 12, color: T.textMuted, marginTop: 20 }}>
        To make your account an admin, run this once in the Supabase SQL editor:<br />
        <code style={{ background: T.surface2, padding: "2px 6px", borderRadius: 4 }}>
          update profiles set is_admin = true where id = auth.uid();
        </code>
      </p>
    </div>
  );
}
