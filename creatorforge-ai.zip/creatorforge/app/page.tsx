import Link from "next/link";
import { T, gradBg } from "@/lib/theme";

export default function LandingPage() {
  return (
    <main style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", padding: "80px 24px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 40 }}>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: gradBg }} />
        <span style={{ fontSize: 15, fontWeight: 700 }}>CreatorForge</span>
      </div>
      <h1 style={{ fontSize: 48, fontWeight: 700, letterSpacing: -1, textAlign: "center", maxWidth: 640, margin: 0 }}>
        Create anything from an idea.
      </h1>
      <p style={{ fontSize: 17, color: T.textMuted, textAlign: "center", maxWidth: 520, marginTop: 18 }}>
        Generate videos, images, voiceovers, scripts, music, thumbnails and more from one AI creative studio. Free for every user.
      </p>
      <div style={{ display: "flex", gap: 12, marginTop: 32 }}>
        <Link href="/signup" style={{ background: gradBg, color: "#fff", padding: "12px 22px", borderRadius: 10, fontWeight: 600, fontSize: 14, textDecoration: "none" }}>
          Start creating free
        </Link>
        <Link href="/login" style={{ border: `1px solid ${T.border}`, color: T.text, padding: "12px 22px", borderRadius: 10, fontWeight: 600, fontSize: 14, textDecoration: "none" }}>
          Log in
        </Link>
      </div>
    </main>
  );
}
