"use client";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { T, gradBg } from "@/lib/theme";

export default function SettingsPage() {
  const [settings, setSettings] = useState<any>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      const { data } = await supabase.from("user_settings").select("*").eq("user_id", user!.id).single();
      setSettings(data);
    })();
  }, []);

  async function handleSave() {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    await supabase.from("user_settings").update({
      default_video_style: settings.default_video_style,
      default_voice: settings.default_voice,
      default_aspect_ratio: settings.default_aspect_ratio,
      language: settings.language,
    }).eq("user_id", user!.id);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  if (!settings) return <p style={{ color: T.textMuted, fontSize: 13.5 }}>Loading…</p>;

  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>Settings</h1>
      <p style={{ fontSize: 13.5, color: T.textMuted, margin: "0 0 20px" }}>Defaults applied across every AI tool.</p>
      <div style={{ maxWidth: 420, display: "flex", flexDirection: "column", gap: 14 }}>
        <Field label="Default video style" value={settings.default_video_style} onChange={(v: string) => setSettings({ ...settings, default_video_style: v })} />
        <Field label="Default voice" value={settings.default_voice} onChange={(v: string) => setSettings({ ...settings, default_voice: v })} />
        <Field label="Default aspect ratio" value={settings.default_aspect_ratio} onChange={(v: string) => setSettings({ ...settings, default_aspect_ratio: v })} />
        <Field label="Language" value={settings.language} onChange={(v: string) => setSettings({ ...settings, language: v })} />
        <button onClick={handleSave} style={{ alignSelf: "flex-start", background: gradBg, color: "#fff", border: "none", borderRadius: 9, padding: "9px 16px", fontWeight: 600, fontSize: 13.5, cursor: "pointer" }}>
          {saved ? "Saved" : "Save changes"}
        </button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: T.textMuted, marginBottom: 6 }}>{label}</div>
      <input value={value ?? ""} onChange={(e) => onChange(e.target.value)} style={{ width: "100%", background: T.surface2, border: `1px solid ${T.border}`, borderRadius: 9, color: T.text, fontSize: 14, padding: "9px 12px", outline: "none", boxSizing: "border-box" }} />
    </label>
  );
}
