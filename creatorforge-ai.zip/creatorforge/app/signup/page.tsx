"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { T, gradBg } from "@/lib/theme";
import Link from "next/link";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "sent" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    setError("");
    const supabase = createClient();
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });
    if (error) {
      setError(error.message);
      setStatus("error");
      return;
    }
    setStatus("sent");
  }

  async function handleGoogle() {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${location.origin}/dashboard` },
    });
  }

  return (
    <main style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ width: 360, border: `1px solid ${T.border}`, borderRadius: 16, padding: 28, background: T.surface }}>
        <h1 style={{ fontSize: 20, fontWeight: 600, margin: "0 0 4px" }}>Create your account</h1>
        <p style={{ fontSize: 13, color: T.textMuted, margin: "0 0 20px" }}>Free forever. No credit card.</p>

        {status === "sent" ? (
          <p style={{ fontSize: 13.5, color: T.text }}>Check your inbox — confirm your email to finish signing up.</p>
        ) : (
          <form onSubmit={handleSignup}>
            <input required placeholder="Full name" value={fullName} onChange={e => setFullName(e.target.value)} style={inputStyle} />
            <input required type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={inputStyle} />
            <input required type="password" minLength={6} placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} />
            {error && <p style={{ color: T.red, fontSize: 12.5, margin: "0 0 10px" }}>{error}</p>}
            <button type="submit" disabled={status === "loading"} style={{ width: "100%", background: gradBg, color: "#fff", border: "none", borderRadius: 9, padding: "10px 0", fontWeight: 600, fontSize: 14, cursor: "pointer", marginTop: 4 }}>
              {status === "loading" ? "Creating account…" : "Create account"}
            </button>
          </form>
        )}

        <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "18px 0" }}>
          <div style={{ flex: 1, height: 1, background: T.border }} /><span style={{ fontSize: 11, color: T.textMuted }}>or</span><div style={{ flex: 1, height: 1, background: T.border }} />
        </div>
        <button onClick={handleGoogle} style={{ width: "100%", border: `1px solid ${T.border}`, background: "none", color: T.text, borderRadius: 9, padding: "10px 0", fontWeight: 500, fontSize: 13.5, cursor: "pointer" }}>
          Continue with Google
        </button>

        <p style={{ fontSize: 12.5, color: T.textMuted, marginTop: 18, textAlign: "center" }}>
          Already have an account? <Link href="/login" style={{ color: T.blue }}>Log in</Link>
        </p>
      </div>
    </main>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%", background: T.surface2, border: `1px solid ${T.border}`, borderRadius: 9,
  color: T.text, fontSize: 14, padding: "10px 12px", outline: "none", marginBottom: 10, boxSizing: "border-box",
};
