import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "CreatorForge AI",
  description: "Create anything from an idea.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "Inter, -apple-system, sans-serif", background: "#0A0A12", color: "#F1F0F7" }}>
        {children}
      </body>
    </html>
  );
}
