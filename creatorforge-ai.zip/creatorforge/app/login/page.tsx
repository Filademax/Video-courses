"use client";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { T, gradBg } from "@/lib/theme";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();
  const params = useSearchParams();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.push(params.get("redirectedFrom") || "/dashboard");
    router.refresh();
  }

  async function handleGoogle() {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${location.origin}/dashboard` },
    });
  }

  return (
    <main style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ width: 360, border: `1px solid ${T.border}`, borderRadius: 16, padding: 28, background: T.surface }}>
        <h1 style={{ fontSize: 20, fontWeight: 600, margin: "0 0 4px" }}>Log in</h1>
        <p style={{ fontSize: 13, color: T.textMuted, margin: "0 0 20px" }}>Welcome back to CreatorForge.</p>

        <form onSubmit={handleLogin}>
          <input required type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={inputStyle} />
          <input required type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} />
          {error && <p style={{ color: T.red, fontSize: 12.5, margin: "0 0 10px" }}>{error}</p>}
          <button type="submit" disabled={loading} style={{ width: "100%", background: gradBg, color: "#fff", border: "none", borderRadius: 9, padding: "10px 0", fontWeight: 600, fontSize: 14, cursor: "pointer", marginTop: 4 }}>
            {loading ? "Logging in…" : "Log in"}
          </button>
        </form>

        <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "18px 0" }}>
          <div style={{ flex: 1, height: 1, background: T.border }} /><span style={{ fontSize: 11, color: T.textMuted }}>or</span><div style={{ flex: 1, height: 1, background: T.border }} />
        </div>
        <button onClick={handleGoogle} style={{ width: "100%", border: `1px solid ${T.border}`, background: "none", color: T.text, borderRadius: 9, padding: "10px 0", fontWeight: 500, fontSize: 13.5, cursor: "pointer" }}>
          Continue with Google
        </button>

        <p style={{ fontSize: 12.5, color: T.textMuted, marginTop: 18, textAlign: "center" }}>
          No account? <Link href="/signup" style={{ color: T.blue }}>Sign up</Link>
        </p>
      </div>
    </main>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%", background: T.surface2, border: `1px solid ${T.border}`, borderRadius: 9,
  color: T.text, fontSize: 14, padding: "10px 12px", outline: "none", marginBottom: 10, boxSizing: "border-box",
};
