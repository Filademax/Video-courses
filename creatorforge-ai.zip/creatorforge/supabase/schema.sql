-- CreatorForge AI — full schema
-- Run this once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run

create extension if not exists "uuid-ossp";

-- ---------- profiles ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  is_admin boolean default false,
  created_at timestamptz default now()
);

-- ---------- user_settings ----------
create table if not exists user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  default_video_style text default 'Cinematic',
  default_voice text default 'Narrator — warm, confident',
  default_aspect_ratio text default '16:9',
  language text default 'English',
  updated_at timestamptz default now()
);

-- ---------- projects ----------
create table if not exists projects (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  name text not null,
  description text,
  tool_type text not null,
  thumbnail_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ---------- project_assets ----------
create table if not exists project_assets (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade not null,
  user_id uuid references auth.users(id) on delete cascade not null,
  asset_type text not null, -- video | image | audio | script | caption | thumbnail
  storage_path text,
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

-- ---------- generation_jobs ----------
create table if not exists generation_jobs (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  tool_type text not null,
  prompt text,
  input jsonb default '{}',
  provider text,
  model text,
  status text default 'queued', -- queued | processing | generating | rendering | completed | failed | cancelled
  progress int default 0,
  output jsonb,
  error text,
  created_at timestamptz default now(),
  completed_at timestamptz
);

-- ---------- generations (finished, saved outputs — mirrors spec's "generations" table) ----------
create table if not exists generations (
  id uuid primary key default uuid_generate_v4(),
  job_id uuid references generation_jobs(id) on delete cascade not null,
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  tool_type text not null,
  output jsonb,
  created_at timestamptz default now()
);

-- ---------- videos / images / audio / scripts / captions ----------
create table if not exists videos (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  storage_path text, duration_seconds int, aspect_ratio text,
  created_at timestamptz default now()
);
create table if not exists images (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  storage_path text, style text,
  created_at timestamptz default now()
);
create table if not exists audio (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  storage_path text, kind text, -- voiceover | music | enhanced
  created_at timestamptz default now()
);
create table if not exists scripts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  content text, format text,
  created_at timestamptz default now()
);
create table if not exists captions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  project_id uuid references projects(id) on delete set null,
  content text, srt_url text, vtt_url text,
  created_at timestamptz default now()
);

-- ---------- templates ----------
create table if not exists templates (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  category text,
  tool_type text,
  config jsonb default '{}',
  is_public boolean default true,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz default now()
);

-- ---------- notifications ----------
create table if not exists notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  title text, body text, read boolean default false,
  created_at timestamptz default now()
);

-- ---------- provider_settings (admin only) ----------
create table if not exists provider_settings (
  id uuid primary key default uuid_generate_v4(),
  provider_name text not null,
  category text not null, -- text | image | video | voice | music | transcription
  model text,
  enabled boolean default false,
  is_default boolean default false,
  is_fallback boolean default false,
  updated_at timestamptz default now()
);

-- ---------- activity_logs ----------
create table if not exists activity_logs (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

-- =========================================================
-- Row Level Security — users can only ever touch their own data
-- =========================================================
alter table profiles enable row level security;
alter table user_settings enable row level security;
alter table projects enable row level security;
alter table project_assets enable row level security;
alter table generation_jobs enable row level security;
alter table generations enable row level security;
alter table videos enable row level security;
alter table images enable row level security;
alter table audio enable row level security;
alter table scripts enable row level security;
alter table captions enable row level security;
alter table notifications enable row level security;
alter table templates enable row level security;
alter table activity_logs enable row level security;
alter table provider_settings enable row level security;

-- profiles
create policy "profiles: own row" on profiles for select using (auth.uid() = id);
create policy "profiles: update own" on profiles for update using (auth.uid() = id);
create policy "profiles: insert own" on profiles for insert with check (auth.uid() = id);

-- user_settings
create policy "settings: owner all" on user_settings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- projects
create policy "projects: owner all" on projects for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- project_assets
create policy "assets: owner all" on project_assets for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- generation_jobs
create policy "jobs: owner all" on generation_jobs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- generations
create policy "generations: owner all" on generations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- videos/images/audio/scripts/captions
create policy "videos: owner all" on videos for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "images: owner all" on images for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "audio: owner all" on audio for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "scripts: owner all" on scripts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "captions: owner all" on captions for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- notifications
create policy "notifications: owner all" on notifications for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- templates: everyone can read public templates; only creators manage their own
create policy "templates: read public" on templates for select using (is_public = true or created_by = auth.uid());
create policy "templates: owner write" on templates for insert with check (created_by = auth.uid());
create policy "templates: owner update" on templates for update using (created_by = auth.uid());

-- activity_logs: users see their own; inserts allowed for self
create policy "activity: owner read" on activity_logs for select using (auth.uid() = user_id);
create policy "activity: owner insert" on activity_logs for insert with check (auth.uid() = user_id);

-- provider_settings: admin only (checked via profiles.is_admin)
create policy "provider_settings: admin read" on provider_settings for select
  using (exists (select 1 from profiles where profiles.id = auth.uid() and profiles.is_admin = true));
create policy "provider_settings: admin write" on provider_settings for all
  using (exists (select 1 from profiles where profiles.id = auth.uid() and profiles.is_admin = true))
  with check (exists (select 1 from profiles where profiles.id = auth.uid() and profiles.is_admin = true));

-- =========================================================
-- Auto-create a profile + default settings row on signup
-- =========================================================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  insert into public.user_settings (user_id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- =========================================================
-- Realtime — let clients subscribe to job progress
-- =========================================================
alter publication supabase_realtime add table generation_jobs;

-- =========================================================
-- Storage buckets (private) — safe to re-run
-- =========================================================
insert into storage.buckets (id, name, public)
values ('videos','videos',false), ('images','images',false), ('audio','audio',false),
       ('uploads','uploads',false), ('projects','projects',false), ('thumbnails','thumbnails',false)
on conflict (id) do nothing;

-- users can only read/write files inside a folder named after their own user id
create policy "storage: owner read" on storage.objects for select
  using (bucket_id in ('videos','images','audio','uploads','projects','thumbnails') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "storage: owner write" on storage.objects for insert
  with check (bucket_id in ('videos','images','audio','uploads','projects','thumbnails') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "storage: owner delete" on storage.objects for delete
  using (bucket_id in ('videos','images','audio','uploads','projects','thumbnails') and (storage.foldername(name))[1] = auth.uid()::text);
