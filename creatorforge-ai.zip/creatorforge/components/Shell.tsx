"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { T, gradBg } from "@/lib/theme";
import { createClient } from "@/lib/supabase/client";

const NAV = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/create", label: "Create" },
  { href: "/projects", label: "Projects" },
  { href: "/history", label: "History" },
  { href: "/settings", label: "Settings" },
];

export default function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <aside style={{ width: 208, borderRight: `1px solid ${T.border}`, padding: "18px 12px", display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "0 8px", marginBottom: 24 }}>
          <div style={{ width: 26, height: 26, borderRadius: 8, background: gradBg }} />
          <span style={{ fontSize: 14.5, fontWeight: 700 }}>CreatorForge</span>
        </div>
        <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {NAV.map((n) => {
            const active = pathname.startsWith(n.href);
            return (
              <Link key={n.href} href={n.href} style={{
                padding: "9px 10px", borderRadius: 9, fontSize: 13.5, fontWeight: active ? 600 : 500,
                background: active ? T.surface2 : "transparent", color: active ? T.text : T.textMuted, textDecoration: "none",
              }}>
                {n.label}
              </Link>
            );
          })}
        </nav>
        <button onClick={handleLogout} style={{ marginTop: "auto", background: "none", border: `1px solid ${T.border}`, color: T.textMuted, borderRadius: 9, padding: "8px 10px", fontSize: 12.5, cursor: "pointer" }}>
          Log out
        </button>
      </aside>
      <main style={{ flex: 1, padding: 28, minWidth: 0 }}>{children}</main>
    </div>
  );
}
