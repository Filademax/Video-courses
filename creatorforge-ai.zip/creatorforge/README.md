# CreatorForge AI

This is a real, working Next.js + Supabase app: email/Google auth, a private
Postgres database with row-level security, a background job system for
generations, realtime progress updates, and a live text-generation tool
(AI Script / Story / Social / Ad — powered by Claude). Video, image, voice,
and music tools run in development mode until you add a provider key —
the adapter pattern in `lib/providers/` makes that a one-file change, not
a rewrite.

I can't create accounts or deploy on your behalf, but everything below is
free, takes about 15 minutes, and needs no coding.

## 1. Create your Supabase project (free)

1. Go to https://supabase.com → New project.
2. Once it's ready, open **SQL Editor** → New query.
3. Paste the entire contents of `supabase/schema.sql` from this project and click **Run**.
   This creates every table, security policy, and storage bucket.
4. Go to **Settings → API** and copy:
   - `Project URL`
   - `anon public` key
   - `service_role` key (keep this one secret — never put it in frontend code)
5. (Optional, for "Continue with Google") Go to **Authentication → Providers → Google** and follow Supabase's setup link to add your Google OAuth credentials.

## 2. Add your keys

Copy `.env.example` to `.env.local` and fill in:

```
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
ANTHROPIC_API_KEY=...      # optional — enables real script/story/social/ad generation
```

Get an Anthropic key at https://console.anthropic.com — leave it blank and those tools just run in mock mode instead, no errors.

## 3. Run it locally (optional, to test first)

```
npm install
npm run dev
```

Visit http://localhost:3000, sign up, and try Create → AI Script.

## 4. Deploy it live (Vercel, free)

1. Push this folder to a GitHub repo.
2. Go to https://vercel.com → New Project → import that repo.
3. In the Vercel project's **Environment Variables**, paste the same four values from `.env.local`.
4. Click **Deploy**. You'll get a live `https://your-app.vercel.app` URL in about a minute.

## 5. Make yourself an admin

In Supabase → SQL Editor, run (after you've signed up once):

```sql
update profiles set is_admin = true where id = auth.uid();
```

Then visit `/admin` on your deployed site.

## What's real vs. mock right now

| Feature | Status |
|---|---|
| Auth (email + Google), sessions, protected routes | Real |
| Database, RLS, storage buckets | Real |
| Realtime job progress | Real |
| AI Script / Story / Social / Ad | Real (calls Claude) if `ANTHROPIC_API_KEY` is set |
| AI Video / Image / Voiceover / Music | Development mode — wire a real key into `lib/providers/index.ts` following the pattern in `text-anthropic.ts` |
| Video editor, content repurposing, admin analytics charts | Not built yet — natural next milestones |

## Project structure

```
app/                  routes (App Router)
  api/generate/        the one endpoint every tool calls
  create/[tool]/       generic tool workflow page
lib/supabase/          browser + server auth clients
lib/providers/         the AI provider abstraction (real + mock)
middleware.ts           route protection
supabase/schema.sql      full database schema + RLS + storage policies
```
