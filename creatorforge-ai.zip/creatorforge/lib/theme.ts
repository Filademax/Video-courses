export const T = {
  bg: "#0A0A12",
  surface: "#131320",
  surface2: "#1A1A2B",
  border: "#26263B",
  text: "#F1F0F7",
  textMuted: "#8D8CA3",
  violet: "#7C5CFF",
  blue: "#4C8DFF",
  green: "#34D399",
  red: "#F87171",
};
export const gradBg = `linear-gradient(90deg, ${T.violet}, ${T.blue})`;
