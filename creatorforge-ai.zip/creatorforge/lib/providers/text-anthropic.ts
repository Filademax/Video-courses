import type { GenerationInput, GenerationResult, TextProvider } from "./types";

// Real, live provider. Used automatically whenever ANTHROPIC_API_KEY is set
// in your environment (server-side only — never exposed to the browser).
export const anthropicTextProvider: TextProvider = {
  name: "anthropic",
  async generate(input: GenerationInput): Promise<GenerationResult> {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) throw new Error("ANTHROPIC_API_KEY not configured");

    const systemPrompt = buildSystemPrompt(input.toolType);

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1200,
        system: systemPrompt,
        messages: [{ role: "user", content: input.prompt }],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Anthropic API error (${res.status}): ${errText}`);
    }

    const data = await res.json();
    const text = (data.content || [])
      .filter((b: { type: string }) => b.type === "text")
      .map((b: { text: string }) => b.text)
      .join("\n");

    return { kind: "text", data: { text }, provider: "anthropic", model: "claude-sonnet-4-6", mock: false };
  },
};

function buildSystemPrompt(toolType: string): string {
  const base = "You are the writing engine inside CreatorForge AI, a content creation platform. Return only the finished content — no preamble, no meta-commentary.";
  switch (toolType) {
    case "ai-script":
      return `${base} Write a complete short-form video script with a hook, introduction, main content, and a call to action.`;
    case "ai-story":
      return `${base} Write a short story with a clear title, setting, and ending.`;
    case "ai-social":
      return `${base} Write platform-specific social captions (Instagram, TikTok, X, LinkedIn) for the given topic, clearly labeled per platform.`;
    case "ai-ad":
      return `${base} Write an advertisement concept: headline, script, and call to action.`;
    default:
      return base;
  }
}
