import type { GenerationInput, GenerationResult } from "./types";
import { anthropicTextProvider } from "./text-anthropic";
import { mockImageProvider, mockVideoProvider, mockVoiceProvider, mockMusicProvider, mockTextProvider } from "./mock";

const TEXT_TOOLS = ["ai-script", "ai-story", "ai-social", "ai-ad", "ai-presentation"];
const IMAGE_TOOLS = ["ai-image", "ai-thumbnail"];
const VIDEO_TOOLS = ["ai-video", "long-video", "image-to-video", "text-to-video", "ai-product-video"];
const VOICE_TOOLS = ["ai-voiceover"];
const MUSIC_TOOLS = ["ai-music"];

// Single entry point every API route calls. This is the "AIService" from
// the spec: it never lets UI code know which underlying provider ran —
// callers just get back a typed GenerationResult.
export async function runGeneration(input: GenerationInput): Promise<GenerationResult> {
  if (TEXT_TOOLS.includes(input.toolType)) {
    if (process.env.ANTHROPIC_API_KEY) {
      try {
        return await anthropicTextProvider.generate(input);
      } catch (err) {
        console.error("Text provider failed, falling back to mock:", err);
        return mockTextProvider.generate(input);
      }
    }
    return mockTextProvider.generate(input);
  }
  if (IMAGE_TOOLS.includes(input.toolType)) {
    // Swap in a real provider here once IMAGE_PROVIDER_API_KEY is set —
    // same pattern as the text provider above.
    return mockImageProvider.generate(input);
  }
  if (VIDEO_TOOLS.includes(input.toolType)) {
    return mockVideoProvider.generate(input);
  }
  if (VOICE_TOOLS.includes(input.toolType)) {
    return mockVoiceProvider.generate(input);
  }
  if (MUSIC_TOOLS.includes(input.toolType)) {
    return mockMusicProvider.generate(input);
  }
  return mockTextProvider.generate(input);
}
