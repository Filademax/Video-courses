export type GenerationInput = {
  toolType: string;
  prompt: string;
  options?: Record<string, unknown>;
};

export type GenerationResult = {
  kind: "text" | "image" | "video" | "audio";
  data: unknown;
  provider: string;
  model?: string;
  mock: boolean;
};

export interface TextProvider {
  name: string;
  generate(input: GenerationInput): Promise<GenerationResult>;
}
export interface ImageProvider {
  name: string;
  generate(input: GenerationInput): Promise<GenerationResult>;
}
export interface VideoProvider {
  name: string;
  generate(input: GenerationInput): Promise<GenerationResult>;
}
export interface VoiceProvider {
  name: string;
  generate(input: GenerationInput): Promise<GenerationResult>;
}
export interface MusicProvider {
  name: string;
  generate(input: GenerationInput): Promise<GenerationResult>;
}
