import type { GenerationInput, GenerationResult } from "./types";

// Development-mode providers. Each returns a realistic, typed placeholder
// so the whole app is testable end to end before a real video/image/voice/
// music API key is added. Swap any of these out by writing a new file with
// the same GenerationResult shape and wiring it in lib/providers/index.ts —
// no other code needs to change.

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export const mockImageProvider = {
  name: "mock-image",
  async generate(input: GenerationInput): Promise<GenerationResult> {
    await delay(400);
    return {
      kind: "image",
      data: { count: 4, prompt: input.prompt },
      provider: "mock-image",
      mock: true,
    };
  },
};

export const mockVideoProvider = {
  name: "mock-video",
  async generate(input: GenerationInput): Promise<GenerationResult> {
    await delay(600);
    return {
      kind: "video",
      data: { durationSeconds: 30, prompt: input.prompt },
      provider: "mock-video",
      mock: true,
    };
  },
};

export const mockVoiceProvider = {
  name: "mock-voice",
  async generate(input: GenerationInput): Promise<GenerationResult> {
    await delay(300);
    return {
      kind: "audio",
      data: { durationSeconds: 24, prompt: input.prompt },
      provider: "mock-voice",
      mock: true,
    };
  },
};

export const mockMusicProvider = {
  name: "mock-music",
  async generate(input: GenerationInput): Promise<GenerationResult> {
    await delay(300);
    return {
      kind: "audio",
      data: { durationSeconds: 45, prompt: input.prompt },
      provider: "mock-music",
      mock: true,
    };
  },
};

export const mockTextProvider = {
  name: "mock-text",
  async generate(input: GenerationInput): Promise<GenerationResult> {
    await delay(300);
    return {
      kind: "text",
      data: {
        text: `[Development mode — add ANTHROPIC_API_KEY to generate this for real]\n\nHook: Here's what matters about "${input.prompt}".\n\nMain content: connect a real text provider to replace this placeholder.\n\nCall to action: try it yourself today.`,
      },
      provider: "mock-text",
      mock: true,
    };
  },
};
